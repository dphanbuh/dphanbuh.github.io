'''Darina Phanbuh and Cory Suiter
Data Project
'''

# Get the directory name for data files
import os.path
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'rawdata.csv')
datafile=open(filename, 'r')
data = datafile.readlines()

iphone=[]
camera=[]

#reads each line of data
for line in data:
   line_one, line_two = line.split(',') 
   #adds data to appropriate list
   iphone.append(float(line_one))
   camera.append(float(line_two))

import matplotlib.pyplot as plt
import numpy as np
from scipy.stats.stats import pearsonr as rvalue
fig, ax = plt.subplots(1,1)
#creates scatter plot
ax.scatter(iphone, camera, color='red')
#creates title and axes labels
ax.set_title(' Digital Cameras Produced vs iPhones Sold')
ax.set_xlabel('iPhones Sold Quarterly 2009-2016')
ax.set_ylabel('Digital Cameras Produced Quarterly 2009-2016')

#creates regression line
ax.plot(iphone, np.poly1d(np.polyfit(iphone, camera, 1))(iphone), color = "black")
#creates area to display r value
bbox_props = dict(boxstyle="circle, pad=0.3", fc="blue", lw=0.5)
r = rvalue(iphone,camera)
#displays and calculates r value
words = 'rvalue = ' + str(r[0])
box = ax.text(60000000, 20000000, words , ha="center", va="center",size=10, bbox=bbox_props)
fig.show()